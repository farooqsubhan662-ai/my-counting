# AI Chat App Website

This is a Vite + React website project based on the JSX file you uploaded. The AI request goes through a small Express backend so the Anthropic API key is not exposed in browser code.

## Run locally

1. Install Node.js 20 or newer.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and add your own Anthropic API key.
4. In one terminal run `npm run server`.
5. In another terminal run `npm run dev`.
6. Open the local URL printed by Vite (usually `http://localhost:5173`).

The chat UI can open without an API key, but actual AI replies require a valid Anthropic API key and an account with API access/billing enabled.

## Production

Run `npm install`, `npm run build`, then set `ANTHROPIC_API_KEY` in your hosting provider's server environment and run `npm start`. This project needs a host that supports a Node.js server (for example, a Node web service). Static-only hosting by itself cannot securely run the `/api/chat` backend.

## Important limitations

- This version stores profile and chat data in the current browser using localStorage. It is not secure account authentication and does not sync across devices.
- The original Pro payment/admin screens are retained from your uploaded file, but their shared review workflow requires a real database/backend before using it for real payments. Do not collect real payments with the demo as-is.
- Never publish your API key or commit the `.env` file.
