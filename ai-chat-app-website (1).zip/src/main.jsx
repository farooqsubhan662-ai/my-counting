import React from "react";
import { createRoot } from "react-dom/client";
import AIChatApp from "./AIChatApp.jsx";
import "./index.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode><AIChatApp /></React.StrictMode>
);