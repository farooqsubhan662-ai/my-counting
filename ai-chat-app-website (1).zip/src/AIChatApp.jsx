import React, { useState, useRef, useEffect } from "react";
import { Send, Plus, MessageSquare, Sparkles, Crown, Check, X, Upload, Shield, Copy, Clock, CheckCircle2, XCircle, LogIn, Mail, User } from "lucide-react";

// Browser-compatible local storage adapter for the original window.storage API.
if (typeof window !== "undefined" && !window.storage) {
  window.storage = {
    async get(key) {
      const value = localStorage.getItem(key);
      return value === null ? null : { value };
    },
    async set(key, value) {
      localStorage.setItem(key, String(value));
      return { value: String(value) };
    },
    async delete(key) {
      localStorage.removeItem(key);
      return true;
    },
  };
}


const JAZZCASH_NUMBER = "03359287637";

export default function AIChatApp() {
  const [authChecked, setAuthChecked] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userProfile, setUserProfile] = useState(null); // { name, email }
  const [loginName, setLoginName] = useState("");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginError, setLoginError] = useState("");

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [isPro, setIsPro] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState("yearly");
  const [step, setStep] = useState("plan"); // plan -> pay -> pending
  const [screenshotPreview, setScreenshotPreview] = useState(null);
  const [screenshotData, setScreenshotData] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [myRequestStatus, setMyRequestStatus] = useState(null); // null | 'pending' | 'approved' | 'rejected'
  const [deviceId, setDeviceId] = useState(null);
  const [chatLoaded, setChatLoaded] = useState(false);
  const [copied, setCopied] = useState(false);

  // Admin panel
  const [showAdmin, setShowAdmin] = useState(false);
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [adminPattern, setAdminPattern] = useState([]);
  const [adminPatternError, setAdminPatternError] = useState(false);
  const [savedAdminPattern, setSavedAdminPattern] = useState(null);
  const [adminPatternLoaded, setAdminPatternLoaded] = useState(false);
  const [patternSetupStage, setPatternSetupStage] = useState("draw"); // draw -> confirm
  const [tempSetupPattern, setTempSetupPattern] = useState([]);
  const [setupMismatch, setSetupMismatch] = useState(false);
  const [adminOwnerEmail, setAdminOwnerEmail] = useState(null);
  const [pendingList, setPendingList] = useState([]);
  const [adminScreenshots, setAdminScreenshots] = useState({});
  const [adminLoading, setAdminLoading] = useState(false);

  const bottomRef = useRef(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);

  // Init: check saved login first
  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("user-profile-v1", false);
        if (res?.value) {
          const profile = JSON.parse(res.value);
          setUserProfile(profile);
          setIsLoggedIn(true);
        }
      } catch (e) {
        // no saved login yet
      } finally {
        setAuthChecked(true);
      }
    })();
  }, []);

  // Init app data (device id + plan status + own pending request status) once logged in
  useEffect(() => {
    if (!isLoggedIn) return;
    (async () => {
      try {
        let id;
        try {
          const idRes = await window.storage.get("device-id-v2", false);
          id = idRes?.value;
        } catch (e) {}
        if (!id) {
          id = "dev_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
          await window.storage.set("device-id-v2", id, false);
        }
        setDeviceId(id);

        try {
          const planRes = await window.storage.get("plan-status-v2", false);
          if (planRes?.value === "pro") setIsPro(true);
        } catch (e) {}

        try {
          const chatRes = await window.storage.get("chat-messages-v1", false);
          if (chatRes?.value) {
            const saved = JSON.parse(chatRes.value);
            if (Array.isArray(saved) && saved.length > 0) setMessages(saved);
          }
        } catch (e) {
          // no saved chat yet
        } finally {
          setChatLoaded(true);
        }

        await refreshMyStatus(id);

        try {
          const ownerRes = await window.storage.get("admin-owner-email", true);
          if (ownerRes?.value) setAdminOwnerEmail(ownerRes.value);
        } catch (e) {
          // no admin owner set yet
        }
      } catch (e) {
        // ignore init errors
      }
    })();
  }, [isLoggedIn]);

  // Persist chat messages whenever they change (after initial load)
  useEffect(() => {
    if (!isLoggedIn || !chatLoaded) return;
    (async () => {
      try {
        await window.storage.set("chat-messages-v1", JSON.stringify(messages), false);
      } catch (e) {
        // ignore storage failure
      }
    })();
  }, [messages, isLoggedIn, chatLoaded]);

  const handleLogin = async () => {
    const name = loginName.trim();
    const email = loginEmail.trim();
    if (!name || !email) {
      setLoginError("Both name and email are required.");
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setLoginError("Please enter a valid email address.");
      return;
    }
    setLoginError("");
    const profile = { name, email };
    try {
      await window.storage.set("user-profile-v1", JSON.stringify(profile), false);
    } catch (e) {
      // continue even if storage fails, keep session in memory
    }
    setUserProfile(profile);
    setIsLoggedIn(true);
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const refreshMyStatus = async (id) => {
    try {
      const res = await window.storage.get("pending-index-v2", true);
      if (res?.value) {
        const list = JSON.parse(res.value);
        const mine = list.filter((r) => r.deviceId === id).sort((a, b) => b.submittedAt - a.submittedAt);
        if (mine.length > 0) {
          setMyRequestStatus(mine[0].status);
          if (mine[0].status === "approved") {
            setIsPro(true);
            try {
              await window.storage.set("plan-status-v2", "pro", false);
            } catch (e) {}
          }
        }
      }
    } catch (e) {
      // no pending index yet
    }
  };

  const autoGrow = (el) => {
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 160) + "px";
  };

  const sendMessage = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const newMessages = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || "AI request failed");
      const replyText = data?.reply || "Sorry, could not get a response.";
      setMessages((prev) => [...prev, { role: "assistant", content: replyText }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Something went wrong. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const newChat = () => {
    setMessages([]);
    setInput("");
    (async () => {
      try {
        await window.storage.set("chat-messages-v1", JSON.stringify([]), false);
      } catch (e) {}
    })();
  };

  const plans = {
    monthly: { label: "Monthly", price: "Rs 1,500", period: "/ month" },
    yearly: { label: "Yearly", price: "Rs 12,000", period: "/ year", badge: "Save 33%" },
  };

  const copyNumber = async () => {
    try {
      await navigator.clipboard.writeText(JAZZCASH_NUMBER);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (e) {
      // ignore
    }
  };

  const compressImage = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const maxDim = 900;
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }
          const canvas = document.createElement("canvas");
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL("image/jpeg", 0.7));
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImage(file);
      setScreenshotData(compressed);
      setScreenshotPreview(compressed);
    } catch (err) {
      // ignore
    }
  };

  const submitPaymentProof = async () => {
    if (!screenshotData || !deviceId) return;
    setSubmitting(true);
    try {
      const id = "req_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);
      await window.storage.set("screenshot-v2:" + id, screenshotData, true);

      let list = [];
      try {
        const res = await window.storage.get("pending-index-v2", true);
        if (res?.value) list = JSON.parse(res.value);
      } catch (e) {}

      list.unshift({
        id,
        deviceId,
        plan: plans[selectedPlan].label,
        price: plans[selectedPlan].price,
        submittedAt: Date.now(),
        status: "pending",
      });
      await window.storage.set("pending-index-v2", JSON.stringify(list), true);

      setMyRequestStatus("pending");
      setStep("pending");
    } catch (err) {
      // ignore failure, allow retry
    } finally {
      setSubmitting(false);
    }
  };

  const closeUpgradeModal = () => {
    setShowUpgrade(false);
    setStep(myRequestStatus === "pending" ? "pending" : "plan");
    setScreenshotData(null);
    setScreenshotPreview(null);
  };

  // ---- Admin ----
  const openAdmin = async () => {
    setShowAdmin(true);
    if (!adminPatternLoaded) {
      try {
        const ownerForLookup = adminOwnerEmail || userProfile?.email;
        const res = await window.storage.get("admin-pattern:" + ownerForLookup, true);
        if (res?.value) setSavedAdminPattern(JSON.parse(res.value));
      } catch (e) {
        // no saved pattern yet
      } finally {
        setAdminPatternLoaded(true);
      }
    }
  };

  const tapPatternDot = (dotIndex) => {
    if (adminPattern.includes(dotIndex)) return;
    const next = [...adminPattern, dotIndex];
    setAdminPattern(next);
    setAdminPatternError(false);
  };

  const finishPatternDraw = () => {
    if (adminPattern.length < 4) return; // require a minimum length pattern

    if (!savedAdminPattern) {
      // Setup mode
      if (patternSetupStage === "draw") {
        setTempSetupPattern(adminPattern);
        setPatternSetupStage("confirm");
        setAdminPattern([]);
      } else {
        const matches =
          adminPattern.length === tempSetupPattern.length &&
          adminPattern.every((v, i) => v === tempSetupPattern[i]);
        if (matches) {
          (async () => {
            try {
              await window.storage.set("admin-pattern:" + userProfile.email, JSON.stringify(tempSetupPattern), true);
              await window.storage.set("admin-owner-email", userProfile.email, true);
            } catch (e) {}
          })();
          setSavedAdminPattern(tempSetupPattern);
          setAdminOwnerEmail(userProfile.email);
          setAdminUnlocked(true);
          loadPendingRequests();
        } else {
          setSetupMismatch(true);
          setTimeout(() => {
            setSetupMismatch(false);
            setAdminPattern([]);
            setPatternSetupStage("draw");
            setTempSetupPattern([]);
          }, 700);
        }
      }
    } else {
      // Unlock mode
      const matches =
        adminPattern.length === savedAdminPattern.length &&
        adminPattern.every((v, i) => v === savedAdminPattern[i]);
      if (matches) {
        setAdminUnlocked(true);
        loadPendingRequests();
      } else {
        setAdminPatternError(true);
        setTimeout(() => {
          setAdminPattern([]);
          setAdminPatternError(false);
        }, 500);
      }
    }
  };

  const resetAdminPattern = () => {
    setAdminPattern([]);
    setAdminPatternError(false);
  };

  const loadPendingRequests = async () => {
    setAdminLoading(true);
    try {
      const res = await window.storage.get("pending-index-v2", true);
      const list = res?.value ? JSON.parse(res.value) : [];
      setPendingList(list.sort((a, b) => b.submittedAt - a.submittedAt));
    } catch (e) {
      setPendingList([]);
    } finally {
      setAdminLoading(false);
    }
  };

  const loadScreenshot = async (id) => {
    if (adminScreenshots[id]) return;
    try {
      const res = await window.storage.get("screenshot-v2:" + id, true);
      if (res?.value) {
        setAdminScreenshots((prev) => ({ ...prev, [id]: res.value }));
      }
    } catch (e) {
      // ignore
    }
  };

  const updateRequestStatus = async (id, status) => {
    const newList = pendingList.map((r) => (r.id === id ? { ...r, status } : r));
    setPendingList(newList);
    try {
      await window.storage.set("pending-index-v2", JSON.stringify(newList), true);
    } catch (e) {
      // ignore
    }
  };

  const themeVars = {
    "--bg": "#12151b",
    "--panel": "#1a1e26",
    "--accent": "#5b8def",
    "--accent-soft": "#243447",
    "--text": "#e8eaf0",
    "--text-dim": "#8b93a6",
    "--border": "#262b35",
    "--gold": "#e8b34a",
    "--green": "#4ade80",
    "--red": "#f87171",
  };

  // While checking saved login, show nothing but a blank themed screen (avoids flicker)
  if (!authChecked) {
    return (
      <div style={themeVars} className="w-full h-full flex items-center justify-center" >
        <div style={{ background: "var(--bg)", minHeight: "600px" }} className="w-full h-full" />
      </div>
    );
  }

  // Not logged in: show login gate, block the rest of the app
  if (!isLoggedIn) {
    return (
      <div
        style={themeVars}
        className="w-full h-full flex items-center justify-center p-4"
      >
        <div
          className="w-full h-full flex items-center justify-center"
          style={{ background: "var(--bg)", color: "var(--text)", minHeight: "600px", fontFamily: "'Inter', system-ui, sans-serif" }}
        >
          <div
            className="w-full max-w-sm rounded-2xl p-6"
            style={{ background: "var(--panel)", border: "1px solid var(--border)" }}
          >
            <div className="flex flex-col items-center text-center mb-5">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center mb-3"
                style={{ background: "var(--accent-soft)" }}
              >
                <Sparkles size={22} style={{ color: "var(--accent)" }} />
              </div>
              <h1 className="text-lg font-semibold">Welcome to AI</h1>
              <p className="text-sm mt-1" style={{ color: "var(--text-dim)" }}>
                Enter your name and email to continue
              </p>
            </div>

            <div className="flex flex-col gap-3">
              <div
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl"
                style={{ background: "var(--bg)", border: "1px solid var(--border)" }}
              >
                <User size={16} style={{ color: "var(--text-dim)" }} />
                <input
                  value={loginName}
                  onChange={(e) => setLoginName(e.target.value)}
                  placeholder="Your name"
                  className="flex-1 bg-transparent outline-none text-sm"
                  style={{ color: "var(--text)" }}
                />
              </div>
              <div
                className="flex items-center gap-2 px-3 py-2.5 rounded-xl"
                style={{ background: "var(--bg)", border: "1px solid var(--border)" }}
              >
                <Mail size={16} style={{ color: "var(--text-dim)" }} />
                <input
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                  placeholder="Your email"
                  className="flex-1 bg-transparent outline-none text-sm"
                  style={{ color: "var(--text)" }}
                />
              </div>

              {loginError && (
                <p className="text-xs" style={{ color: "var(--red)" }}>
                  {loginError}
                </p>
              )}

              <button
                onClick={handleLogin}
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-sm font-semibold mt-1"
                style={{ background: "var(--accent)", color: "#0d1117" }}
              >
                <LogIn size={15} />
                Continue
              </button>

              <p className="text-xs text-center mt-1" style={{ color: "var(--text-dim)" }}>
                Once you're logged in, you won't be asked again.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      style={themeVars}
      className="w-full h-full flex"
    >
      <div
        className="flex w-full h-full"
        style={{ background: "var(--bg)", color: "var(--text)", minHeight: "600px", fontFamily: "'Inter', system-ui, sans-serif" }}
      >
        {/* Sidebar */}
        <div
          className="hidden sm:flex flex-col w-56 shrink-0 p-3"
          style={{ background: "var(--panel)", borderRight: "1px solid var(--border)" }}
        >
          <button
            onClick={newChat}
            className="flex items-center gap-2 px-3 py-2 rounded-lg mb-4 text-sm font-medium transition-colors"
            style={{ background: "var(--accent-soft)", color: "var(--text)" }}
          >
            <Plus size={16} />
            New chat
          </button>
          <div className="flex items-center gap-2 px-2 text-xs uppercase tracking-wide" style={{ color: "var(--text-dim)" }}>
            <MessageSquare size={13} />
            This session's chat
          </div>
          <div className="mt-2 px-2 text-sm truncate" style={{ color: "var(--text-dim)" }}>
            {messages.length > 0
              ? messages[0].content.slice(0, 40)
              : "No conversation yet"}
          </div>

          <div className="flex-1" />

          <div
            className="flex items-center justify-between px-2 py-2 mb-1 text-xs"
            style={{ color: "var(--text-dim)" }}
          >
            <span className="truncate">{userProfile?.name}</span>
            <button
              onClick={async () => {
                try {
                  await window.storage.delete("user-profile-v1", false);
                } catch (e) {}
                setIsLoggedIn(false);
                setUserProfile(null);
                setLoginName("");
                setLoginEmail("");
              }}
              className="shrink-0 underline"
            >
              Logout
            </button>
          </div>

          {(!adminOwnerEmail || adminOwnerEmail === userProfile?.email) && (
            <button
              onClick={openAdmin}
              className="flex items-center gap-2 px-3 py-2 rounded-lg mb-2 text-xs font-medium transition-colors"
              style={{ color: "var(--text-dim)" }}
            >
              <Shield size={14} />
              Admin panel
            </button>
          )}

          {isPro ? (
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium"
              style={{ background: "var(--accent-soft)", color: "var(--gold)" }}
            >
              <Crown size={16} />
              Pro Member
            </div>
          ) : myRequestStatus === "pending" ? (
            <button
              onClick={() => {
                setStep("pending");
                setShowUpgrade(true);
              }}
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium"
              style={{ background: "var(--accent-soft)", color: "var(--text-dim)" }}
            >
              <Clock size={16} />
              Review pending
            </button>
          ) : (
            <button
              onClick={() => {
                setStep("plan");
                setShowUpgrade(true);
              }}
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors"
              style={{ background: "var(--accent-soft)", color: "var(--gold)" }}
            >
              <Crown size={16} />
              Upgrade
            </button>
          )}
        </div>

        {/* Main chat area */}
        <div className="flex flex-col flex-1 min-w-0">
          <div
            className="flex items-center justify-between px-5 py-3 shrink-0"
            style={{ borderBottom: "1px solid var(--border)" }}
          >
            <div className="flex items-center gap-2">
              <Sparkles size={18} style={{ color: "var(--accent)" }} />
              <span className="font-semibold text-sm">AI</span>
            </div>
            {!isPro && (
              <button
                onClick={() => {
                  setStep(myRequestStatus === "pending" ? "pending" : "plan");
                  setShowUpgrade(true);
                }}
                className="sm:hidden flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium"
                style={{ background: "var(--accent-soft)", color: "var(--gold)" }}
              >
                <Crown size={13} />
                Upgrade
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6">
            {messages.length === 0 && !loading && (
              <div className="h-full flex flex-col items-center justify-center text-center px-4">
                <Sparkles size={32} style={{ color: "var(--accent)" }} className="mb-3" />
                <h1 className="text-xl font-semibold mb-1">What can I help with today?</h1>
                <p className="text-sm max-w-sm" style={{ color: "var(--text-dim)" }}>
                  Ask a question, get help writing, or just have a conversation.
                </p>
              </div>
            )}

            <div className="max-w-2xl mx-auto flex flex-col gap-5">
              {messages.map((m, i) => (
                <div
                  key={i}
                  className="flex gap-3"
                  style={{ flexDirection: m.role === "user" ? "row-reverse" : "row" }}
                >
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-semibold"
                    style={{
                      background: m.role === "user" ? "var(--accent)" : "var(--accent-soft)",
                      color: m.role === "user" ? "#0d1117" : "var(--accent)",
                    }}
                  >
                    {m.role === "user" ? "You" : "AI"}
                  </div>
                  <div
                    className="px-4 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap"
                    style={{
                      background: m.role === "user" ? "var(--accent-soft)" : "var(--panel)",
                      maxWidth: "80%",
                      border: m.role === "assistant" ? "1px solid var(--border)" : "none",
                    }}
                  >
                    {m.content}
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex gap-3">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs font-semibold"
                    style={{ background: "var(--accent-soft)", color: "var(--accent)" }}
                  >
                    AI
                  </div>
                  <div
                    className="px-4 py-2.5 rounded-2xl text-sm flex gap-1 items-center"
                    style={{ background: "var(--panel)", border: "1px solid var(--border)" }}
                  >
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          </div>

          <div className="px-4 sm:px-8 pb-5 pt-2 shrink-0">
            <div
              className="max-w-2xl mx-auto flex items-end gap-2 rounded-2xl px-3 py-2"
              style={{ background: "var(--panel)", border: "1px solid var(--border)" }}
            >
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  autoGrow(e.target);
                }}
                onKeyDown={handleKeyDown}
                placeholder="Type your message..."
                rows={1}
                className="flex-1 bg-transparent outline-none resize-none text-sm py-1.5"
                style={{ color: "var(--text)", maxHeight: "160px" }}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || loading}
                className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-opacity"
                style={{
                  background: "var(--accent)",
                  color: "#0d1117",
                  opacity: !input.trim() || loading ? 0.4 : 1,
                }}
              >
                <Send size={15} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Upgrade Modal */}
      {showUpgrade && (
        <div
          className="fixed inset-0 flex items-center justify-center p-4 z-50"
          style={{ background: "rgba(0,0,0,0.6)" }}
          onClick={closeUpgradeModal}
        >
          <div
            className="w-full max-w-sm rounded-2xl p-5 max-h-[85vh] overflow-y-auto"
            style={{ background: "var(--panel)", border: "1px solid var(--border)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Crown size={18} style={{ color: "var(--gold)" }} />
                <h2 className="font-semibold text-base">Upgrade to Pro</h2>
              </div>
              <button onClick={closeUpgradeModal} style={{ color: "var(--text-dim)" }}>
                <X size={18} />
              </button>
            </div>

            {step === "plan" && (
              <>
                <ul className="flex flex-col gap-2 mb-5">
                  {["Unlimited questions", "Faster responses", "Access to longer conversations"].map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm" style={{ color: "var(--text)" }}>
                      <Check size={15} style={{ color: "var(--accent)" }} />
                      {item}
                    </li>
                  ))}
                </ul>

                <div className="flex flex-col gap-2 mb-5">
                  {Object.entries(plans).map(([key, plan]) => (
                    <button
                      key={key}
                      onClick={() => setSelectedPlan(key)}
                      className="flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-colors"
                      style={{
                        border: selectedPlan === key ? "1.5px solid var(--accent)" : "1px solid var(--border)",
                        background: selectedPlan === key ? "var(--accent-soft)" : "transparent",
                      }}
                    >
                      <div>
                        <div className="text-sm font-medium">{plan.label}</div>
                        <div className="text-xs" style={{ color: "var(--text-dim)" }}>
                          {plan.price} <span>{plan.period}</span>
                        </div>
                      </div>
                      {plan.badge && (
                        <span
                          className="text-xs px-2 py-0.5 rounded-full font-medium"
                          style={{ background: "var(--gold)", color: "#0d1117" }}
                        >
                          {plan.badge}
                        </span>
                      )}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setStep("pay")}
                  className="w-full py-2.5 rounded-xl text-sm font-semibold"
                  style={{ background: "var(--gold)", color: "#0d1117" }}
                >
                  Continue
                </button>
              </>
            )}

            {step === "pay" && (
              <>
                <p className="text-sm mb-3" style={{ color: "var(--text-dim)" }}>
                  Send <strong style={{ color: "var(--text)" }}>{plans[selectedPlan].price}</strong> to the JazzCash number below, then upload a screenshot of the payment.
                </p>

                <div
                  className="flex items-center justify-between px-3 py-3 rounded-xl mb-4"
                  style={{ background: "var(--accent-soft)" }}
                >
                  <div>
                    <div className="text-xs" style={{ color: "var(--text-dim)" }}>JazzCash Number</div>
                    <div className="text-base font-semibold tracking-wide">{JAZZCASH_NUMBER}</div>
                  </div>
                  <button
                    onClick={copyNumber}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium"
                    style={{ background: "var(--panel)", color: "var(--text)" }}
                  >
                    <Copy size={13} />
                    {copied ? "Copied" : "Copy"}
                  </button>
                </div>

                <label
                  className="flex flex-col items-center justify-center gap-2 py-6 rounded-xl cursor-pointer mb-4"
                  style={{ border: "1.5px dashed var(--border)" }}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                  {screenshotPreview ? (
                    <img src={screenshotPreview} alt="Screenshot preview" className="max-h-40 rounded-lg" />
                  ) : (
                    <>
                      <Upload size={22} style={{ color: "var(--text-dim)" }} />
                      <span className="text-xs" style={{ color: "var(--text-dim)" }}>
                        Upload payment screenshot
                      </span>
                    </>
                  )}
                </label>

                <button
                  onClick={submitPaymentProof}
                  disabled={!screenshotData || submitting}
                  className="w-full py-2.5 rounded-xl text-sm font-semibold transition-opacity"
                  style={{
                    background: "var(--gold)",
                    color: "#0d1117",
                    opacity: !screenshotData || submitting ? 0.5 : 1,
                  }}
                >
                  {submitting ? "Submitting..." : "Submit screenshot"}
                </button>
                <button
                  onClick={() => setStep("plan")}
                  className="w-full py-2 mt-2 rounded-xl text-xs font-medium"
                  style={{ color: "var(--text-dim)" }}
                >
                  Go back
                </button>
              </>
            )}

            {step === "pending" && (
              <div className="flex flex-col items-center text-center py-4">
                <Clock size={32} style={{ color: "var(--gold)" }} className="mb-3" />
                <h3 className="font-semibold mb-1">Submitted for review</h3>
                <p className="text-sm" style={{ color: "var(--text-dim)" }}>
                  Your payment is waiting for confirmation. You'll become Pro as soon as it's approved.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Admin Modal */}
      {showAdmin && (
        <div
          className="fixed inset-0 flex items-center justify-center p-4 z-50"
          style={{ background: "rgba(0,0,0,0.6)" }}
          onClick={() => setShowAdmin(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl p-5 max-h-[85vh] overflow-y-auto"
            style={{ background: "var(--panel)", border: "1px solid var(--border)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Shield size={18} style={{ color: "var(--accent)" }} />
                <h2 className="font-semibold text-base">Admin Panel</h2>
              </div>
              <button onClick={() => setShowAdmin(false)} style={{ color: "var(--text-dim)" }}>
                <X size={18} />
              </button>
            </div>

            {!adminUnlocked ? (
              <div className="flex flex-col items-center gap-3">
                <p className="text-sm text-center" style={{ color: "var(--text-dim)" }}>
                  {!savedAdminPattern
                    ? setupMismatch
                      ? "Pattern didn't match, please try again."
                      : patternSetupStage === "draw"
                      ? "First time setup — create your pattern (at least 4 dots)."
                      : "Now draw the same pattern again to confirm."
                    : adminPatternError
                    ? "Incorrect pattern, please try again."
                    : "Draw your pattern."}
                </p>
                <div
                  className="grid grid-cols-3 gap-4 p-4 rounded-xl"
                  style={{ background: "var(--bg)", border: "1px solid var(--border)" }}
                >
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((dot) => {
                    const selected = adminPattern.includes(dot);
                    const isError = (adminPatternError || setupMismatch) && selected;
                    return (
                      <button
                        key={dot}
                        onClick={() => tapPatternDot(dot)}
                        className="w-10 h-10 rounded-full flex items-center justify-center transition-colors"
                        style={{
                          background: isError ? "var(--red)" : selected ? "var(--accent)" : "var(--panel)",
                          border: "1.5px solid var(--border)",
                        }}
                      >
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ background: selected ? "#0d1117" : "var(--text-dim)" }}
                        />
                      </button>
                    );
                  })}
                </div>
                <div className="flex gap-2 w-full">
                  <button
                    onClick={resetAdminPattern}
                    className="flex-1 py-2 rounded-xl text-xs font-medium"
                    style={{ color: "var(--text-dim)", border: "1px solid var(--border)" }}
                  >
                    Clear
                  </button>
                  <button
                    onClick={finishPatternDraw}
                    disabled={adminPattern.length < 4}
                    className="flex-1 py-2 rounded-xl text-xs font-semibold transition-opacity"
                    style={{
                      background: "var(--accent)",
                      color: "#0d1117",
                      opacity: adminPattern.length < 4 ? 0.4 : 1,
                    }}
                  >
                    {!savedAdminPattern && patternSetupStage === "draw" ? "Continue" : "Confirm"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase tracking-wide" style={{ color: "var(--text-dim)" }}>
                    Payment Requests
                  </span>
                  <button onClick={loadPendingRequests} className="text-xs" style={{ color: "var(--accent)" }}>
                    Refresh
                  </button>
                </div>

                {adminLoading && (
                  <div className="text-sm text-center py-4" style={{ color: "var(--text-dim)" }}>
                    Loading...
                  </div>
                )}

                {!adminLoading && pendingList.length === 0 && (
                  <div className="text-sm text-center py-4" style={{ color: "var(--text-dim)" }}>
                    No requests
                  </div>
                )}

                {pendingList.map((req) => (
                  <div
                    key={req.id}
                    className="rounded-xl p-3"
                    style={{ background: "var(--bg)", border: "1px solid var(--border)" }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <div className="text-sm font-medium">{req.plan} — {req.price}</div>
                        <div className="text-xs" style={{ color: "var(--text-dim)" }}>
                          {new Date(req.submittedAt).toLocaleString()}
                        </div>
                      </div>
                      <span
                        className="text-xs px-2 py-1 rounded-full font-medium flex items-center gap-1"
                        style={{
                          background:
                            req.status === "approved" ? "rgba(74,222,128,0.15)" :
                            req.status === "rejected" ? "rgba(248,113,113,0.15)" : "var(--accent-soft)",
                          color:
                            req.status === "approved" ? "var(--green)" :
                            req.status === "rejected" ? "var(--red)" : "var(--gold)",
                        }}
                      >
                        {req.status === "approved" && <CheckCircle2 size={12} />}
                        {req.status === "rejected" && <XCircle size={12} />}
                        {req.status === "pending" && <Clock size={12} />}
                        {req.status}
                      </span>
                    </div>

                    {adminScreenshots[req.id] ? (
                      <img src={adminScreenshots[req.id]} alt="Payment proof" className="w-full rounded-lg mb-2" />
                    ) : (
                      <button
                        onClick={() => loadScreenshot(req.id)}
                        className="text-xs mb-2"
                        style={{ color: "var(--accent)" }}
                      >
                        View screenshot
                      </button>
                    )}

                    {req.status === "pending" && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => updateRequestStatus(req.id, "approved")}
                          className="flex-1 py-1.5 rounded-lg text-xs font-medium"
                          style={{ background: "var(--green)", color: "#0d1117" }}
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => updateRequestStatus(req.id, "rejected")}
                          className="flex-1 py-1.5 rounded-lg text-xs font-medium"
                          style={{ background: "var(--red)", color: "#0d1117" }}
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <style>{`
        .typing-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: var(--text-dim);
          animation: bounce 1.2s infinite;
        }
        .typing-dot:nth-child(2) { animation-delay: 0.15s; }
        .typing-dot:nth-child(3) { animation-delay: 0.3s; }
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.5; }
          30% { transform: translateY(-4px); opacity: 1; }
        }
        textarea::-webkit-scrollbar { width: 4px; }
      `}</style>
    </div>
  );
}
